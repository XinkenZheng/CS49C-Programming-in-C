#include <stdio.h>

//the following program prints a pyramid pattern with a given input.
int main(void) {

printf("Enter a number of rows \n");
int rows;
scanf("%d", &rows);
int a, b = 0; 

//run through the number or rows
for (int i = 1; i <= rows; i++) 
  if (i % 2 != 0) {   //if the number of rows is odd;
    for (a = b + 1; a < b + i; a++) 
      printf("%d""*",a);  //print a with *;
      printf("%d\n",a++); //increase number of a;
      b = a; 
  }
  
  else {              //if it is even.
     // update value of b 
     b = b + i - 1; 
     // print a with the '*' in decreasing order 
     for (a = b; a > b - i + 1; a--) 
        printf("%d""*", a); 
        printf("%d\n",a);
       
    } 
}


//Test cases
/*
Enter a number of rows
6
1
3*2
4*5*6
10*9*8*7
11*12*13*14*15
21*20*19*18*17*16

Enter a number of rows
4
1
3*2
4*5*6
10*9*8*7

Enter a number of rows
10
1
3*2
4*5*6
10*9*8*7
11*12*13*14*15
21*20*19*18*17*16
22*23*24*25*26*27*28
36*35*34*33*32*31*30*29
37*38*39*40*41*42*43*44*45
55*54*53*52*51*50*49*48*47*46

*/

