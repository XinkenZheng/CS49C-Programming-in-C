#include <stdio.h>


//prints out a 5 row dimond shape.
int main()
{
int i, k, indent = 4;
int row = 5;

//prints the top half of the diamond.
for (k = 1; k <= row; k++)
{
  //prints one indent for every row
  for (i = 1; i <= indent; i++)
    printf(" ");
    indent--;
  for (i = 1; i <= 2 * k - 1; i++)
      printf("*");
      printf("\n");
}
indent = 1;

//prints the bottom half of the diamond
for (k = 1; k <= row - 1; k++)
{
  for (i = 1; i <= indent; i++)
    printf(" ");
    indent++;
  for (i = 1 ; i <= 2 *(row - k)- 1; i++)
    printf("*");
    printf("\n");
}
    return 0;
}

/* ./main
    *
   ***
  *****
 *******
*********
 *******
  *****
   ***
    *
*/